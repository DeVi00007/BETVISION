/**
 * API Service modul - api-football.com integráció
 */

const API_BASE_URL = 'https://v3.football.api-sports.io';
const API_KEY = 'c2e659119f7d1c12b7bb8768fa0a9a2f';

let lastRequestTime = 0;
const MIN_REQUEST_INTERVAL = 500;

async function enforceRateLimit(): Promise<void> {
  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;
  if (timeSinceLastRequest < MIN_REQUEST_INTERVAL) {
    await new Promise((resolve) =>
      setTimeout(resolve, MIN_REQUEST_INTERVAL - timeSinceLastRequest)
    );
  }
  lastRequestTime = Date.now();
}

async function apiCall(
  endpoint: string,
  params?: Record<string, string | number | undefined>
): Promise<any[] | null> {
  try {
    await enforceRateLimit();

    const queryParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          queryParams.append(key, String(value));
        }
      });
    }

    const url = `${API_BASE_URL}/${endpoint}${queryParams.toString() ? '?' + queryParams.toString() : ''}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'x-rapidapi-host': 'v3.football.api-sports.io',
        'x-rapidapi-key': API_KEY,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      console.warn(`[API] HTTP hiba: ${response.status} - ${endpoint}`);
      return null;
    }

    const data = await response.json() as { response?: any[]; errors?: any };

    if (data.errors && Object.keys(data.errors).length > 0) {
      console.warn('[API] API hiba:', data.errors);
      return null;
    }

    if (!data.response || data.response.length === 0) {
      console.warn(`[API] Üres válasz: ${endpoint}`);
      return null;
    }

    return data.response;
  } catch (error) {
    console.error(`[API] Hálózati hiba (${endpoint}):`, error);
    return null;
  }
}

export async function getLiveMatches(): Promise<any[] | null> {
  return apiCall('fixtures', { live: 'all' });
}

export async function getFixtures(
  date?: string,
  league?: number
): Promise<any[] | null> {
  const today = new Date().toISOString().split('T')[0];
  return apiCall('fixtures', {
    date: date || today,
    league,
    season: new Date().getFullYear(),
    timezone: 'Europe/Budapest',
  });
}

export async function getOdds(fixtureId: number): Promise<any[] | null> {
  return apiCall('odds', {
    fixture: fixtureId,
    bet: 1,
    bookmaker: 1,
  });
}

export async function getLeagues(): Promise<any[] | null> {
  return apiCall('leagues');
}

export async function getFixtureStatistics(fixtureId: number): Promise<any[] | null> {
  return apiCall('fixtures/statistics', { fixture: fixtureId });
}

export async function getFixtureEvents(fixtureId: number): Promise<any[] | null> {
  return apiCall('fixtures/events', { fixture: fixtureId });
}

export async function getStandings(leagueId: number, season?: number): Promise<any[] | null> {
  return apiCall('standings', {
    league: leagueId,
    season: season || new Date().getFullYear(),
  });
}
